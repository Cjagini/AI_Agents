import { useEffect, useState, CSSProperties } from 'react';

// Define the shape of our active particles
interface Particle {
  id: string;
  x: number;          // Horizontal start percentage (0 - 100)
  yOffset?: number;   // Initial vertical shift (for immediate screen-populating)
  size: number;       // Dimensions in pixels (medium)
  duration: number;   // Travel transition duration in seconds
  swayDuration: number; // Sway frequency duration in seconds
  swayDistance: number; // Max horizontal sway displacement in pixels
  opacity: number;
  rotationSpeed?: number; // Spin rate (for snowflake)
  color?: string;     // Hex color (for balloon)
}

interface EffectOverlayProps {
  effectType: 'snowflakes' | 'balloons' | null;
  timestamp: number;  // Seed trigger time to detect new clicks
}

// Crisp Vector-drawn, geometrically accurate Snowflake
const SnowflakeSVG = () => (
  <svg 
    viewBox="0 0 24 24" 
    className="w-full h-full text-slate-100 select-none opacity-90 drop-shadow-md" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="1.8" 
    strokeLinecap="round"
  >
    <line x1="12" y1="2" x2="12" y2="22" />
    <line x1="2" y1="12" x2="22" y2="12" />
    <line x1="5" y1="5" x2="19" y2="19" />
    <line x1="5" y1="19" x2="19" y2="5" />
    {/* Fine crystalline branches */}
    <polyline points="9,4 12,7 15,4" />
    <polyline points="9,20 12,17 15,20" />
    <polyline points="4,9 7,12 4,15" />
    <polyline points="20,9 18,12 20,15" />
    <circle cx="12" cy="12" r="2.5" className="fill-slate-100/20" />
  </svg>
);

// High-end elegant Balloon Vector with glossy look, tie knot, and trailing string
const BalloonSVG = ({ color }: { color: string }) => (
  <svg 
    viewBox="0 0 40 70" 
    className="w-full h-full select-none drop-shadow-lg"
  >
    <defs>
      {/* 3D sphere gradient highlight */}
      <radialGradient id={`balloon-glow-${color.replace('#', '')}`} cx="35%" cy="30%" r="65%">
        <stop offset="0%" stopColor="#ffffff" stopOpacity="0.5" />
        <stop offset="40%" stopColor={color} />
        <stop offset="100%" stopColor="#000000" stopOpacity="0.3" />
      </radialGradient>
    </defs>
    {/* Balloon body */}
    <ellipse 
      cx="20" 
      cy="24" 
      rx="16" 
      ry="21" 
      fill={`url(#balloon-glow-${color.replace('#', '')})`} 
    />
    {/* Highlight sheen curve */}
    <ellipse 
      cx="14" 
      cy="14" 
      rx="4" 
      ry="7" 
      fill="rgba(255,255,255,0.45)" 
      transform="rotate(-15 14 14)" 
    />
    {/* Elegant knot base */}
    <polygon 
      points="17,44 23,44 20,39" 
      fill={color} 
    />
    <ellipse cx="20" cy="44" rx="3" ry="1.5" fill={color} />
    {/* Soft wavy string path underneath balloon */}
    <path 
      d="M20,45 Q17,53 23,60 T20,70" 
      fill="none" 
      stroke="rgba(148, 163, 184, 0.6)" 
      strokeWidth="1.2" 
      strokeLinecap="round" 
    />
  </svg>
);

const BALLOON_COLORS = [
  '#f43f5e', // deep bright rose
  '#0ea5e9', // vivid sky blue
  '#10b981', // emerald
  '#f59e0b', // warm golden amber
  '#8b5cf6', // royal purple
  '#06b6d4', // bright cyan
  '#f97316', // corporate orange
];

export default function EffectOverlay({ effectType, timestamp }: EffectOverlayProps) {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    if (!effectType) {
      // Clear overlay immediately on stop/reset
      setParticles([]);
      return;
    }

    setParticles([]); // reset pool for new trigger
    const now = Date.now();
    const spawnDuration = 5000; // Active spawning for exactly 5 seconds

    // 1. --- SEED PRE-POPULATION ---
    // Instantly spawn a set of particles distributed vertically
    // so the environment is instantly filled without waiting for them to travel.
    const initialParticles: Particle[] = [];
    const count = effectType === 'snowflakes' ? 18 : 10;
    
    for (let i = 0; i < count; i++) {
      const isSnow = effectType === 'snowflakes';
      
      initialParticles.push({
        id: `init-${i}-${now}`,
        x: Math.random() * 92 + 4, // keep away from absolute corners
        yOffset: Math.random() * 85 + 5, // distributed vertical offset (%)
        size: isSnow 
          ? Math.random() * 8 + 24 // medium size: 24px - 32px
          : Math.random() * 12 + 44, // medium size: 44px - 56px
        duration: isSnow 
          ? Math.random() * 1.8 + 3.2 
          : Math.random() * 1.6 + 3.4,
        swayDuration: Math.random() * 1.5 + 2.0,
        swayDistance: isSnow ? Math.random() * 25 + 20 : Math.random() * 15 + 10,
        opacity: Math.random() * 0.25 + 0.7,
        rotationSpeed: isSnow ? (Math.random() > 0.5 ? 1 : -1) * (Math.random() * 1.5 + 0.5) : undefined,
        color: isSnow ? undefined : BALLOON_COLORS[Math.floor(Math.random() * BALLOON_COLORS.length)],
      });
    }
    setParticles(initialParticles);

    // 2. --- REAL-TIME SPANNING GENERATOR ---
    // Spawns a steady cascade of particles from top/bottom for exactly 5 seconds
    const intervalTime = effectType === 'snowflakes' ? 140 : 200; // ms between spawns
    const spawnTimer = setInterval(() => {
      // Safety calculation: stop spawning once 5 seconds elapse
      if (Date.now() - now >= spawnDuration) {
        clearInterval(spawnTimer);
        return;
      }

      setParticles((prev) => {
        const isSnow = effectType === 'snowflakes';
        const newId = `live-${Math.random()}-${Date.now()}`;
        const newParticle: Particle = {
          id: newId,
          x: Math.random() * 92 + 4,
          yOffset: 0, // starts fully off-screen
          size: isSnow 
            ? Math.random() * 8 + 24 // medium: 24 - 32px
            : Math.random() * 12 + 44, // medium: 44 - 56px
          duration: isSnow 
            ? Math.random() * 1.8 + 3.2 // 3.2s - 5s
            : Math.random() * 1.6 + 3.4, // 3.4s - 5s
          swayDuration: Math.random() * 1.5 + 2.0,
          swayDistance: isSnow ? Math.random() * 25 + 20 : Math.random() * 15 + 10,
          opacity: Math.random() * 0.25 + 0.7,
          rotationSpeed: isSnow ? (Math.random() > 0.5 ? 1 : -1) * (Math.random() * 1.5 + 0.5) : undefined,
          color: isSnow ? undefined : BALLOON_COLORS[Math.floor(Math.random() * BALLOON_COLORS.length)],
        };

        // Garbage collect old particles that have drifted off screen to prevent leaks
        // A particle is safely dead once its translation duration + 1s buffer has completed.
        return [...prev, newParticle];
      });
    }, intervalTime);

    // Clean up interval on unmount or effect alteration
    return () => {
      clearInterval(spawnTimer);
    };
  }, [effectType, timestamp]);

  // Clean up individual particles from DOM after their animation completes
  const handleAnimationEnd = (id: string) => {
    setParticles((prev) => prev.filter((p) => p.id !== id));
  };

  return (
    <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none z-40 select-none">
      {/* Stylesheet injector for zero-config hardware accelerated keyframes config */}
      <style>{`
        @keyframes verticalFall {
          0% {
            transform: translateY(-80px);
          }
          100% {
            transform: translateY(calc(100vh + 100px));
          }
        }
        @keyframes verticalFloatUp {
          0% {
            transform: translateY(calc(100vh + 120px));
          }
          100% {
            transform: translateY(-160px);
          }
        }
        @keyframes horizontalSway {
          0%, 100% {
            transform: translateX(0px);
          }
          50% {
            transform: var(--sway-transform);
          }
        }
        @keyframes spinning {
          0% {
            transform: rotate(0deg);
          }
          100% {
            transform: var(--spin-transform);
          }
        }

        .particle-translate-fall {
          animation-name: verticalFall;
          animation-timing-function: linear;
          animation-fill-mode: forwards;
        }

        .particle-translate-rise {
          animation-name: verticalFloatUp;
          animation-timing-function: cubic-bezier(0.25, 1, 0.5, 1);
          animation-fill-mode: forwards;
        }

        .particle-sway {
          animation-name: horizontalSway;
          animation-iteration-count: infinite;
          animation-timing-function: ease-in-out;
        }

        .particle-spin {
          animation-name: spinning;
          animation-iteration-count: infinite;
          animation-timing-function: linear;
        }
      `}</style>

      {particles.map((p) => {
        const isSnowflake = effectType === 'snowflakes';
        
        // Compute animation dynamic styling parameters
        const customVariables = {
          '--sway-transform': `translateX(${p.swayDistance}px)`,
          '--spin-transform': p.rotationSpeed ? `rotate(${p.rotationSpeed > 0 ? 360 : -360}deg)` : 'rotate(360deg)',
        } as CSSProperties;

        // Vertical positioning
        // If a particle was spawned initialized with a yOffset, override its vertical start index
        const itemStyle: CSSProperties = {
          position: 'absolute',
          left: `${p.x}%`,
          width: `${p.size}px`,
          height: isSnowflake ? `${p.size}px` : `${p.size * 1.5}px`,
          opacity: p.opacity,
          ...customVariables,
        };

        // If it starts in the middle of active run, offset the start (simulated via animation-delay negative offsets)
        let animationStyle: CSSProperties = {
          animationDuration: `${p.duration}s`,
        };

        if (p.yOffset && p.yOffset > 0) {
          // Negative anim delay pushes the animation starting point forward in time!
          // Highly elegant way to instantiate half-completed animations
          const offsetTime = (p.yOffset / 100) * p.duration;
          animationStyle.animationDelay = `-${offsetTime}s`;
        }

        const swayStyle: CSSProperties = {
          animationDuration: `${p.swayDuration}s`,
          animationDelay: `-${Math.random() * 2}s`, // randomize sway start phase
        };

        return (
          <div
            key={p.id}
            className={isSnowflake ? 'particle-translate-fall' : 'particle-translate-rise'}
            style={{ ...itemStyle, ...animationStyle }}
            onAnimationEnd={() => handleAnimationEnd(p.id)}
          >
            <div 
              className="particle-sway" 
              style={swayStyle}
            >
              {isSnowflake ? (
                // Nest spinning container inside the sway container for snowflake
                <div 
                  className="particle-spin" 
                  style={{ animationDuration: `${Math.abs(100 / (p.rotationSpeed || 1))}s` }}
                >
                  <SnowflakeSVG />
                </div>
              ) : (
                <BalloonSVG color={p.color || '#ec4899'} />
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
