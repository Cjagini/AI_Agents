import { useEffect, useRef } from 'react';

interface AudioVisualizerProps {
  isActive: boolean;
  effectType: 'snowflakes' | 'balloons' | null;
}

export default function AudioVisualizer({ isActive, effectType }: AudioVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let phase = 0;

    // Handle high DPI retina display support
    const handleResize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };

    handleResize();
    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(canvas);

    const render = () => {
      const width = canvas.width / (window.devicePixelRatio || 1);
      const height = canvas.height / (window.devicePixelRatio || 1);

      // Deep obsidian charcoal background with grid lines
      ctx.fillStyle = '#0f172a'; // slate-900
      ctx.fillRect(0, 0, width, height);

      // Draw subtle grid lines
      ctx.strokeStyle = 'rgba(51, 65, 85, 0.2)'; // slate-700 20%
      ctx.lineWidth = 1;

      // Vertical grids
      const gridSpacing = 30;
      for (let x = 0; x < width; x += gridSpacing) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }

      // Horizontal grids
      for (let y = 0; y < height; y += gridSpacing) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw reference center line
      ctx.strokeStyle = 'rgba(71, 85, 105, 0.4)'; // slate-600 40%
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(0, height / 2);
      ctx.lineTo(width, height / 2);
      ctx.stroke();
      ctx.setLineDash([]); // Reset line dash

      // Render oscilloscope waveform
      ctx.lineWidth = 2.5;

      if (isActive && effectType === 'snowflakes') {
        // Crystalline ice-wave: high-freq, complex multi-harmonics
        const gradient = ctx.createLinearGradient(0, 0, width, 0);
        gradient.addColorStop(0, '#38bdf8'); // sky-400
        gradient.addColorStop(0.5, '#7dd3fc'); // sky-300
        gradient.addColorStop(1, '#0284c7'); // sky-600
        ctx.strokeStyle = gradient;

        ctx.shadowColor = '#0ea5e9';
        ctx.shadowBlur = 8;

        ctx.beginPath();
        for (let x = 0; x < width; x++) {
          const progress = x / width;
          const decay = Math.sin(progress * Math.PI); // Pin the ends to center for elegance

          // Compose 3 distinct frequencies simulating crystal sparkle
          const wave1 = Math.sin(x * 0.08 + phase) * 12;
          const wave2 = Math.sin(x * 0.18 - phase * 1.5) * 5;
          const wave3 = Math.cos(x * 0.28 + phase * 2.2) * 2;
          
          const y = (height / 2) + (wave1 + wave2 + wave3) * decay;

          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
        ctx.shadowBlur = 0; // reset

        phase += 0.15; // Animation speed

      } else if (isActive && effectType === 'balloons') {
        // Bouncy floating swell: low-freq warm rolling waves
        const gradient = ctx.createLinearGradient(0, 0, width, 0);
        gradient.addColorStop(0, '#ec4899'); // pink-500
        gradient.addColorStop(0.5, '#f472b6'); // pink-400
        gradient.addColorStop(1, '#db2777'); // pink-600
        ctx.strokeStyle = gradient;

        ctx.shadowColor = '#f43f5e';
        ctx.shadowBlur = 8;

        ctx.beginPath();
        for (let x = 0; x < width; x++) {
          const progress = x / width;
          const decay = Math.sin(progress * Math.PI);

          // Broad, smooth balloon-float hum frequencies
          const wave1 = Math.sin(x * 0.02 + phase) * 16;
          const wave2 = Math.cos(x * 0.05 - phase * 0.8) * 6;
          const wave3 = Math.sin(x * 0.01 + phase * 0.4) * 4;

          const y = (height / 2) + (wave1 + wave2 + wave3) * decay;

          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
        ctx.shadowBlur = 0; // reset

        phase += 0.06; // slower, floating motion

      } else {
        // Flat line with a minor, beautiful "idle hum" to prove it's live
        const gradient = ctx.createLinearGradient(0, 0, width, 0);
        gradient.addColorStop(0, '#506784');
        gradient.addColorStop(1, '#334155');
        ctx.strokeStyle = gradient;

        ctx.beginPath();
        for (let x = 0; x < width; x++) {
          const progress = x / width;
          const decay = Math.sin(progress * Math.PI);
          
          // Minor micro-vibrations
          const y = (height / 2) + (Math.sin(x * 0.3 + phase) * 0.75 + Math.cos(x * 0.7 - phase * 1.5) * 0.25) * decay;

          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();

        phase += 0.03;
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
      resizeObserver.disconnect();
    };
  }, [isActive, effectType]);

  return (
    <div className="relative w-full h-full min-h-[140px] rounded-lg border border-slate-700/80 overflow-hidden shadow-inner">
      <canvas
        id="oscillator_grid"
        ref={canvasRef}
        className="w-full h-full block"
      />
      {/* Absolute labels on visualizer overlay */}
      <div className="absolute top-2 left-3 px-1.5 py-0.5 rounded bg-slate-950/80 border border-slate-800 text-[10px] font-mono tracking-wider text-slate-400 pointer-events-none uppercase">
        Signal Output
      </div>
      <div className="absolute bottom-2 right-3 font-mono text-[9px] text-slate-500 pointer-events-none">
        {isActive ? (
          <span className="text-emerald-400 animate-pulse font-medium">● ACTIVE SYNTHESIS</span>
        ) : (
          <span>RESTING STATE</span>
        )}
      </div>
    </div>
  );
}
