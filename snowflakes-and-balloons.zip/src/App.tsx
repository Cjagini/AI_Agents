import { useState, useEffect } from 'react';
import { 
  Snowflake, 
  Volume2, 
  VolumeX, 
  RefreshCw, 
  HelpCircle, 
  Activity, 
  Copy, 
  Check,
  Terminal,
  CirclePlay,
  Pocket
} from 'lucide-react';
import { audioSynth } from './utils/audio';
import AudioVisualizer from './components/AudioVisualizer';
import EffectOverlay from './components/EffectOverlay';

export default function App() {
  const [activeEffect, setActiveEffect] = useState<'snowflakes' | 'balloons' | null>(null);
  const [effectTimestamp, setEffectTimestamp] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [volume, setVolume] = useState<number>(0.5);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [totalTriggers, setTotalTriggers] = useState<number>(0);
  const [showHelpDocs, setShowHelpDocs] = useState<boolean>(true);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Diagnostic log history to mimic professional monitoring terminal
  const [logs, setLogs] = useState<string[]>([
    'SYSTEM: Initializing atmospheric control desk...',
    'ACOUSTICS: Core oscillator pipelines initialized.',
    'STATUS: Standby. Ready for client command triggers.'
  ]);

  // Helper to push formal timestamps into our action log feed
  const addLog = (message: string) => {
    const now = new Date();
    const timeStr = `${now.toTimeString().split(' ')[0]}.${String(now.getMilliseconds()).padStart(3, '0')}`;
    setLogs((prev) => [`[${timeStr}] ${message}`, ...prev.slice(0, 11)]); // cap logs at 12 items
  };

  // Trigger main animation state and direct the Web Audio Synth
  const triggerSimulation = (type: 'snowflakes' | 'balloons') => {
    const nowStamp = Date.now();
    setActiveEffect(type);
    setEffectTimestamp(nowStamp);
    setTimeLeft(5.00);
    setTotalTriggers((prev) => prev + 1);

    addLog(`INITIATED: ${type.toUpperCase()} test pattern (5000ms limit).`);

    const activeVolume = isMuted ? 0 : volume;

    if (type === 'snowflakes') {
      audioSynth.playSnow(activeVolume);
      addLog(`AUDIO: Filtered lowpass pinkish-noise gust + 7 high-freq shimmers.`);
    } else {
      audioSynth.playBalloons(activeVolume);
      addLog(`AUDIO: Warm major third triad wave + 3 rubber tension squeaks.`);
    }
  };

  // Immediate halt handler
  const terminateAllActions = () => {
    audioSynth.stopAll();
    setActiveEffect(null);
    setTimeLeft(0);
    addLog('ALERT: EMERGENCY ABORT command received. Terminating all waveforms and visuals.');
  };

  // Copy helper for command lines in the help guide
  const copyCommandToClipboard = (commandText: string, index: number) => {
    navigator.clipboard.writeText(commandText);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
    addLog(`CLIENT: Command copied to clipboard -> "${commandText}"`);
  };

  // Main countdown ticker (accurate sub-second resolution based on timestamps)
  useEffect(() => {
    if (!activeEffect) return;

    const interval = setInterval(() => {
      const elapsed = (Date.now() - effectTimestamp) / 1000;
      if (elapsed >= 5.0) {
        setActiveEffect(null);
        setTimeLeft(0);
        addLog(`COMPLETE: Particle spawning completed. Low-frequency feedback terminated.`);
      } else {
        setTimeLeft(Math.max(0, 5.0 - elapsed));
      }
    }, 25); // high speed update for precise decimals

    return () => clearInterval(interval);
  }, [activeEffect, effectTimestamp]);

  // Handle dynamic volume alterations on-the-fly inside current playing node
  useEffect(() => {
    if (activeEffect) {
      // Re-trigger sound at the adjusted volume to represent active feedback
      const activeVolume = isMuted ? 0 : volume;
      if (activeEffect === 'snowflakes') {
        audioSynth.playSnow(activeVolume);
      } else {
        audioSynth.playBalloons(activeVolume);
      }
      addLog(`GAIN: Main level adjusted to ${(volume * 100).toFixed(0)}% (${isMuted ? 'MUTED' : 'LIVE'}).`);
    }
  }, [volume, isMuted]);

  // Guide command list definitions
  const setupCommands = [
    { title: "Retrieve dependency manifest", cmd: "npm install" },
    { title: "Launch development server", cmd: "npm run dev" },
    { title: "Standard production build", cmd: "npm run build" },
  ];

  return (
    <div className="relative min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans transition-colors duration-500 overflow-x-hidden select-none">
      
      {/* 1. Interactive Ambient Rendering Canvas behind standard controls */}
      <EffectOverlay effectType={activeEffect} timestamp={effectTimestamp} />

      {/* 2. Top-tier Luxury Header */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-md relative z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 ml-2 rounded-lg bg-sky-950 border border-sky-800">
              <Activity className="w-5 h-5 text-sky-400 rotate-90" />
            </div>
            <div>
              <h1 className="text-md font-semibold tracking-wide font-mono uppercase text-slate-200">
                AetherAtmosphere Console
              </h1>
              <p className="text-[10px] text-slate-500 font-mono tracking-wider uppercase">
                Atmospheric Dynamics & Electro-Acoustic Synth Desk
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
            <div className="px-3 py-1.5 rounded bg-slate-900/60 border border-slate-800">
              <span className="text-slate-500">SYSTEM STATE: </span>
              {activeEffect ? (
                <span className="text-emerald-400 animate-pulse font-medium">RUNNING_{activeEffect.toUpperCase()}</span>
              ) : (
                <span className="text-sky-400 font-medium">STANDBY_AWAITING_INPUT</span>
              )}
            </div>
            <div className="px-3 py-1.5 rounded bg-slate-900/60 border border-slate-800">
              <span className="text-slate-500">TRIGGERS: </span>
              <span className="text-slate-200 font-bold">{totalTriggers}</span>
            </div>
          </div>
        </div>
      </header>

      {/* 3. Main Operational Space */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 relative z-30">
        
        {/* Left Side Column: Control Desks & Triggers */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          
          {/* Main Visualizer Panel */}
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-5 backdrop-blur-sm relative overflow-hidden shadow-lg flex flex-col h-full min-h-[300px]">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-sky-500 animate-ping" />
                <h3 className="text-xs font-mono tracking-wider text-slate-400 uppercase">
                  Procedural Acoustic Oscillation Grid
                </h3>
              </div>
              {activeEffect && (
                <div className="text-[10px] font-mono text-slate-400 flex items-center gap-2">
                  <span>Current Event Sequence Timer:</span>
                  <span className="px-2 py-0.5 rounded bg-slate-950 font-bold text-sky-400 font-mono text-sm border border-slate-800">
                    {timeLeft.toFixed(2)}s
                  </span>
                </div>
              )}
            </div>

            {/* Simulated Live Oscillation Grid */}
            <div className="flex-1 min-h-[160px] relative">
              <AudioVisualizer isActive={activeEffect !== null} effectType={activeEffect} />
            </div>

            {/* Waveform Stats Overlay */}
            <div className="grid grid-cols-3 gap-2 mt-4 text-[10px] font-mono text-slate-500 border-t border-slate-800 pt-3">
              <div>
                <span className="block text-slate-400 uppercase text-[9px] tracking-wider mb-0.5">Sample Source</span>
                <span className="text-slate-300 font-medium">{activeEffect ? 'WebAudioSynth.node' : 'Gould_Loop_Resting'}</span>
              </div>
              <div>
                <span className="block text-slate-400 uppercase text-[9px] tracking-wider mb-0.5">Target Frequency</span>
                <span className="text-slate-300 font-medium">
                  {activeEffect === 'snowflakes' ? '~1500Hz - 2700Hz' : activeEffect === 'balloons' ? 'Chord Triad (261Hz-568Hz)' : 'Resting State (0.3Hz)'}
                </span>
              </div>
              <div>
                <span className="block text-slate-400 uppercase text-[9px] tracking-wider mb-0.5">Decay Threshold</span>
                <span className="text-slate-300 font-medium">{activeEffect ? 'Precisely 5000ms' : 'Static Infinite'}</span>
              </div>
            </div>
          </div>

          {/* Interactive Trigger Panel (Side-by-Side Dual Deck Layout) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Snowflake Deck */}
            <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-6 backdrop-blur-sm shadow-md flex flex-col justify-between hover:border-slate-700/80 transition-all duration-300 group">
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div className="p-3 rounded-lg bg-sky-950/50 border border-sky-800 group-hover:bg-sky-900/40 transition-colors">
                    <Snowflake className="w-6 h-6 text-sky-400 group-hover:rotate-45 transition-transform duration-700" />
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-950/40 text-sky-400 border border-sky-900/60 font-semibold tracking-wider">
                    DECOY_FALL
                  </span>
                </div>

                <h4 className="text-md font-semibold tracking-wide text-slate-200">
                  Snowflake Synthesizer
                </h4>
                <p className="text-xs text-slate-400 mt-1 lines-2 leading-relaxed">
                  Generates an ambient blanket of medium sized (24px-32px) high-definition geometric ice crystals falling from top to bottom.
                </p>

                {/* Micro tech telemetry to make it look formal */}
                <div className="my-4 space-y-1.5 border-y border-slate-800/50 py-3 text-[10px] font-mono text-slate-500">
                  <div className="flex justify-between">
                    <span>Gravity Metric:</span>
                    <span className="text-slate-300">Default (3.2s – 5.0s rate)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Density Coefficient:</span>
                    <span className="text-slate-300">Continuous 140ms Spawn</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Acoustic Spec:</span>
                    <span className="text-slate-300">Lowpass Whisper Wind + High Chimes</span>
                  </div>
                </div>
              </div>

              <button
                id="btn_snowflakes"
                onClick={() => triggerSimulation('snowflakes')}
                disabled={activeEffect === 'snowflakes'}
                className="w-full mt-2 py-3 px-4 rounded-lg font-mono text-xs font-semibold uppercase tracking-wider text-white bg-sky-600 hover:bg-sky-500 disabled:bg-slate-800/80 disabled:text-slate-500 disabled:border overflow-hidden disabled:border-slate-800 transition-all duration-200 transform active:scale-98 cursor-pointer disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-sky-950/50"
              >
                {activeEffect === 'snowflakes' ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Synthesizing Snow...
                  </>
                ) : (
                  <>
                    <CirclePlay className="w-4 h-4 text-sky-200" />
                    Trigger Snowflakes
                  </>
                )}
              </button>
            </div>

            {/* Balloon Deck */}
            <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-6 backdrop-blur-sm shadow-md flex flex-col justify-between hover:border-slate-700/80 transition-all duration-300 group">
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div className="p-3 rounded-lg bg-pink-950/40 border border-pink-900/60 group-hover:bg-pink-900/30 transition-colors">
                    <Pocket className="w-6 h-6 text-pink-400 group-hover:-translate-y-0.5 transition-transform" />
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-pink-950/40 text-pink-400 border border-pink-900/60 font-semibold tracking-wider">
                    BUOYANCY_LIFT
                  </span>
                </div>

                <h4 className="text-md font-semibold tracking-wide text-slate-200">
                  Balloon Ascender
                </h4>
                <p className="text-xs text-slate-400 mt-1 lines-2 leading-relaxed">
                  Triggers an upflow of multi-colored, glossy medium-sized helium balloons ascending from the lower edge of the screen upwards.
                </p>

                {/* Telemetry data */}
                <div className="my-4 space-y-1.5 border-y border-slate-800/50 py-3 text-[10px] font-mono text-slate-500">
                  <div className="flex justify-between">
                    <span>Upflow Velocity:</span>
                    <span className="text-slate-300">Rising (3.4s - 5.0s rate)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Gas Concentration:</span>
                    <span className="text-slate-300">Helium (99.8% Fill)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Acoustic Spec:</span>
                    <span className="text-slate-300">Tri-Harmonic Glides & Friction Rubs</span>
                  </div>
                </div>
              </div>

              <button
                id="btn_balloons"
                onClick={() => triggerSimulation('balloons')}
                disabled={activeEffect === 'balloons'}
                className="w-full mt-2 py-3 px-4 rounded-lg font-mono text-xs font-semibold uppercase tracking-wider text-white bg-pink-600 hover:bg-pink-500 disabled:bg-slate-800/80 disabled:text-slate-500 disabled:border disabled:border-slate-800 transition-all duration-200 transform active:scale-98 cursor-pointer disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-pink-950/50"
              >
                {activeEffect === 'balloons' ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Ascending Balloons...
                  </>
                ) : (
                  <>
                    <CirclePlay className="w-4 h-4 text-pink-200" />
                    Trigger Balloons
                  </>
                )}
              </button>
            </div>

          </div>

        </div>

        {/* Right Side Column: Command Center Console / Volume / Logs */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          
          {/* Controls Deck */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden backdrop-blur-md">
            <h4 className="text-xs font-mono font-semibold tracking-wider text-slate-400 uppercase mb-4 flex items-center gap-2">
              <Activity className="w-4 h-4 text-sky-500" />
              Master Synth Desk
            </h4>

            {/* Countdown Slider/Indicator */}
            <div className="mb-6 bg-slate-950/70 rounded-lg p-4 border border-slate-900">
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 mb-1.5">
                <span>ACTIVE SIMULATION PROGRESS</span>
                <span>{timeLeft > 0 ? `${((timeLeft/5)*100).toFixed(0)}%` : 'IDLE'}</span>
              </div>
              <div className="w-full h-2 rounded bg-slate-800/80 overflow-hidden relative">
                <div 
                  className={`h-full transition-all duration-300 ${activeEffect === 'snowflakes' ? 'bg-sky-500' : 'bg-pink-500'}`}
                  style={{ width: `${(timeLeft / 5) * 100}%` }}
                />
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-[10px] font-mono text-slate-400">Time Counter</span>
                <span className="text-xs font-mono font-bold text-slate-300">
                  {timeLeft.toFixed(2)}s / 5.00s
                </span>
              </div>
            </div>

            {/* Volume Dashboard Controller */}
            <div className="space-y-4 mb-6">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-400">SYNTH GAIN LEVEL:</span>
                <span className={`font-semibold ${isMuted ? 'text-red-400' : 'text-slate-200'}`}>
                  {isMuted ? 'MUTED' : `${Math.round(volume * 100)}%`}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  id="btn_mute"
                  onClick={() => {
                    setIsMuted(!isMuted);
                    addLog(`CLIENT: Audio volume states mutated to ${!isMuted ? 'MUTED' : 'LIVE'}.`);
                  }}
                  className={`p-2 rounded border transition-colors cursor-pointer ${
                    isMuted 
                      ? 'bg-red-950/40 border-red-800 text-red-400 hover:bg-red-900/40' 
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
                  title={isMuted ? "Unmute Volume" : "Mute Sound"}
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                
                <input
                  id="slider_volume"
                  type="range"
                  min="0"
                  max="100"
                  value={volume * 100}
                  onChange={(e) => {
                    setVolume(Number(e.target.value) / 100);
                    if (isMuted) setIsMuted(false);
                  }}
                  className="flex-1 accent-sky-500 bg-slate-950 rounded-lg h-1.5 cursor-pointer appearance-none"
                />
              </div>
            </div>

            {/* Halting Button Command */}
            <button
              id="btn_terminate"
              onClick={terminateAllActions}
              className="w-full py-2.5 rounded-lg font-mono text-[11px] font-bold uppercase tracking-wider text-red-400 border border-red-900/60 bg-red-950/20 hover:bg-red-950/45 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              Cancel Active Synthesis
            </button>
          </div>

          {/* Core Logs Window */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden backdrop-blur-md flex-1 flex flex-col min-h-[220px]">
            <h4 className="text-xs font-mono font-semibold tracking-wider text-slate-400 uppercase mb-3 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              Operational Ticker Logs
            </h4>

            {/* Text Area simulating live console */}
            <div className="flex-1 bg-slate-950/90 rounded-lg p-3.5 border border-slate-900/80 font-mono text-[10px] leading-relaxed text-emerald-500 overflow-y-auto space-y-1 select-text scrollbar-thin scrollbar-thumb-slate-800">
              {logs.map((log, index) => (
                <div 
                  key={index} 
                  className={`truncate whitespace-pre-wrap ${index === 0 ? 'text-emerald-300 font-semibold border-l-2 border-emerald-400 pl-1.5' : 'text-emerald-500/80'}`}
                >
                  {log}
                </div>
              ))}
            </div>
          </div>

        </div>

      </main>

      {/* 4. Execution, Build & Test Manual Desk */}
      <section className="bg-slate-950 border-t border-slate-900 py-8 relative z-50 mt-12 bg-radial from-slate-900/20 to-slate-950">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-sky-400" />
              <h2 className="text-sm font-semibold font-mono uppercase text-slate-200 tracking-wider">
                Console Execution & Local Verification Guide
              </h2>
            </div>
            <button
              id="btn_toggle_help"
              onClick={() => setShowHelpDocs(!showHelpDocs)}
              className="text-xs font-mono text-sky-400 hover:text-sky-300 cursor-pointer border-b border-sky-400/30 pb-0.5"
            >
              {showHelpDocs ? "Minimize Panel" : "Maximize Panel"}
            </button>
          </div>

          {showHelpDocs && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mt-4">
              
              {/* Commands column */}
              <div className="md:col-span-7 space-y-4">
                <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
                  This application is written inside a standard, modern full-stack ready sandboxed server container. To download, run, and test this simulation desk on your own personal workstation, follow these consecutive commands:
                </p>

                <div className="space-y-2.5">
                  {setupCommands.map((item, idx) => (
                    <div key={idx} className="bg-slate-900/40 border border-slate-800 rounded-lg p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div>
                        <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500 font-semibold block mb-0.5">
                          Step {idx + 1}: {item.title}
                        </span>
                        <code className="text-sky-400 font-mono text-[11px] bg-slate-950 px-2 py-0.5 rounded border border-slate-900">
                          {item.cmd}
                        </code>
                      </div>
                      <button
                        onClick={() => copyCommandToClipboard(item.cmd, idx)}
                        className="self-start sm:self-center px-3 py-1.5 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-[10px] font-mono tracking-wider uppercase transition-colors border border-slate-700/60 cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
                      >
                        {copiedIndex === idx ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            Copy Line
                          </>
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Instructions column */}
              <div className="md:col-span-5 bg-slate-900/20 border border-slate-800/50 rounded-xl p-5 text-xs text-slate-400 space-y-4 font-mono leading-relaxed">
                <div>
                  <h4 className="text-slate-200 font-bold uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                    How to verify triggers & sound
                  </h4>
                  <ul className="space-y-2 text-[11px] list-disc pl-4 text-slate-400">
                    <li>
                      <strong className="text-slate-300">Clicking Snowflakes:</strong> Deploys realistic ❄️ falling crystal vectors across the screen overlay. Pre-instantiated snowflakes trigger instantly, followed by continuous top-border spawning for precisely 5.0 seconds. High frequency crystalline bells sound over gentle lowpass sweeping pink noise.
                    </li>
                    <li>
                      <strong className="text-slate-300">Clicking Balloons:</strong> Creates colored 🎈 balloon SVGs with trailing lines rising smoothly from bottom to top. It generates balloon float chords sliding upward alongside organic rubber friction squeaks.
                    </li>
                  </ul>
                </div>

                <div className="border-t border-slate-800 pt-3">
                  <h4 className="text-slate-200 font-bold uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    Audio Authority constraints
                  </h4>
                  <p className="text-[11px] leading-relaxed text-slate-400">
                    To satisfy security policies, web browsers require user interaction (such as clicking the buttons or volume bars) before playing synthesizer audio. Sound triggers will start immediately upon your first button click!
                  </p>
                </div>
              </div>

            </div>
          )}
        </div>
      </section>

      {/* Footer credits */}
      <footer className="py-4 text-center text-[10px] font-mono text-slate-600 bg-slate-950 border-t border-slate-900/60 relative z-50">
        AetherAtmosphere Precision Simulation Console © 2026. All synthesized audio and particles are computed on client-side sandboxes.
      </footer>
    </div>
  );
}
