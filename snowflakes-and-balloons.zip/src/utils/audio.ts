/**
 * Audio Synthesizer Engine using Web Audio API
 * Generates custom, asset-free procedural audio.
 */

class AudioSynth {
  private ctx: AudioContext | null = null;
  private activeNodes: { stop: () => void }[] = [];

  constructor() {
    // Lazy initialized on user command
  }

  /**
   * Initializes or resumes the AudioContext safely
   */
  private initContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  /**
   * Stops all active audio nodes immediately to prevent overlapping
   */
  public stopAll() {
    this.activeNodes.forEach(node => {
      try {
        node.stop();
      } catch (e) {
        // Safe catch for nodes already stopped
      }
    });
    this.activeNodes = [];
  }

  /**
   * Synthesizes "gentle falling snow"
   * Combination of filtered soft pinkish-white noise for wind 
   * and high-pitched crystalline sine-wave chime sparks.
   */
  public playSnow(volumeValue: number = 0.5) {
    const ctx = this.initContext();
    this.stopAll();

    const duration = 5.0; // precisely 5 seconds
    const now = ctx.currentTime;

    // 1. --- WIND BASE (White Noise source mapped through a low-pass sweeping filter) ---
    const bufferSize = ctx.sampleRate * duration;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = buffer;

    // Filter to sweep low frequencies to simulate soft wind blow
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(320, now);
    filter.Q.setValueAtTime(2.0, now);

    // Dynamic sweeping of wind frequency for gentle cold blow
    filter.frequency.exponentialRampToValueAtTime(120, now + 1.2);
    filter.frequency.exponentialRampToValueAtTime(380, now + 2.5);
    filter.frequency.exponentialRampToValueAtTime(180, now + 3.8);
    filter.frequency.linearRampToValueAtTime(80, now + duration);

    // Wind volume envelope
    const windGain = ctx.createGain();
    windGain.gain.setValueAtTime(0.0, now);
    windGain.gain.linearRampToValueAtTime(0.08 * volumeValue, now + 0.3);
    windGain.gain.exponentialRampToValueAtTime(0.05 * volumeValue, now + 2.0);
    windGain.gain.exponentialRampToValueAtTime(0.07 * volumeValue, now + 3.5);
    windGain.gain.linearRampToValueAtTime(0.0, now + duration);

    noiseSource.connect(filter);
    filter.connect(windGain);
    windGain.connect(ctx.destination);

    noiseSource.start(now);
    noiseSource.stop(now + duration);

    // 2. --- ICE SHIMMERS (Random bell triggers representing snowflakes reflecting light) ---
    // Schedule 7 short glassy chimes over the 5 seconds
    const sparkleTimes = [0.1, 0.7, 1.3, 2.0, 2.8, 3.6, 4.3];
    const shimmers: { stop: () => void }[] = [];

    sparkleTimes.forEach((delay) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      // Extremely high-frequency glassy chimes
      const targetFreq = 1500 + Math.random() * 1200;
      osc.frequency.setValueAtTime(targetFreq, now + delay);

      // Tremolo/vibrato for bell-like shimmering
      const vibrato = ctx.createOscillator();
      vibrato.frequency.value = 16; // Hz speed
      const vibratoGain = ctx.createGain();
      vibratoGain.gain.value = 8.0;
      vibrato.connect(vibratoGain);
      vibratoGain.connect(osc.frequency);
      
      // Decay envelope
      gain.gain.setValueAtTime(0.0, now + delay);
      gain.gain.linearRampToValueAtTime(0.12 * volumeValue, now + delay + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      vibrato.start(now + delay);
      osc.start(now + delay);
      
      vibrato.stop(now + delay + 0.4);
      osc.stop(now + delay + 0.4);

      shimmers.push({
        stop: () => {
          try {
            osc.stop();
            vibrato.stop();
          } catch (e) {}
        }
      });
    });

    this.activeNodes.push({
      stop: () => {
        try {
          noiseSource.stop();
        } catch (e) {}
        shimmers.forEach(s => s.stop());
      }
    });
  }

  /**
   * Synthesizes "light floating balloon" sound
   * Harmonic, airy sliding tones evoking buoyancy,
   * interspersed with rapid organic squeaks of a rubber balloon.
   */
  public playBalloons(volumeValue: number = 0.5) {
    const ctx = this.initContext();
    this.stopAll();

    const duration = 5.0; // precisely 5 seconds
    const now = ctx.currentTime;

    // 1. --- BUOYANCY HARMONICS (Three climbing triangle oscs creating a pure rising major triad) ---
    const rootFreqs = [261.63, 329.63, 392.00]; // C4, E4, G4 major chord
    const oscList: OscillatorNode[] = [];
    const lfoList: OscillatorNode[] = [];

    rootFreqs.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle'; // Warm acoustic tone
      osc.frequency.setValueAtTime(freq, now);

      // Slide frequency slowly upwards to represent rising balloons
      osc.frequency.linearRampToValueAtTime(freq * 1.45, now + duration);

      // Low frequency pitch drift (LFO) for floating feel
      const lfo = ctx.createOscillator();
      lfo.frequency.setValueAtTime(4 + i * 0.8, now);
      const lfoGain = ctx.createGain();
      lfoGain.gain.setValueAtTime(5.0, now);
      lfo.connect(lfoGain);
      lfoGain.connect(osc.frequency);

      // Envelope structure
      gain.gain.setValueAtTime(0.0, now);
      // Staggered balloon releases
      const entranceDelay = i * 0.25;
      gain.gain.linearRampToValueAtTime(0.0, now);
      gain.gain.linearRampToValueAtTime(0.06 * volumeValue, now + entranceDelay + 0.6);
      gain.gain.setValueAtTime(0.06 * volumeValue, now + duration - 1.2);
      gain.gain.linearRampToValueAtTime(0.0, now + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      lfo.start(now);
      osc.start(now);

      lfo.stop(now + duration);
      osc.stop(now + duration);

      oscList.push(osc);
      lfoList.push(lfo);
    });

    // 2. --- RUBBER SQUEAKS ---
    // Generates balloon rubber friction squeaks at periodic points
    const squeakDelays = [0.4, 2.1, 3.7];
    const squeakers: { stop: () => void }[] = [];

    squeakDelays.forEach((delay) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      // Fast pitch squeak: climbs rapidly then drops slightly
      osc.frequency.setValueAtTime(600, now + delay);
      osc.frequency.exponentialRampToValueAtTime(1100, now + delay + 0.05);
      osc.frequency.linearRampToValueAtTime(750, now + delay + 0.18);

      // Bandpass filtering to focus the "rub" sound
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(850, now + delay);

      gain.gain.setValueAtTime(0.0, now + delay);
      gain.gain.linearRampToValueAtTime(0.08 * volumeValue, now + delay + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.2);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + delay);
      osc.stop(now + delay + 0.25);

      squeakers.push({
        stop: () => {
          try {
            osc.stop();
          } catch (e) {}
        }
      });
    });

    this.activeNodes.push({
      stop: () => {
        oscList.forEach(o => { try { o.stop(); } catch (e) {} });
        lfoList.forEach(l => { try { l.stop(); } catch (e) {} });
        squeakers.forEach(s => s.stop());
      }
    });
  }
}

export const audioSynth = new AudioSynth();
